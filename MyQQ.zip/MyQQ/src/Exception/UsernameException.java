package Exception;
//@author��
public class UsernameException extends Exception {

}
