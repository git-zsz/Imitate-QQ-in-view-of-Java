package Exception;
//@author��
public class UsernameNotFoundException extends Exception {

}
