package Exception;
//@author��
public class StateException extends Exception {

}
