package Exception;
//@author��
public class PasswordException extends Exception {

}
