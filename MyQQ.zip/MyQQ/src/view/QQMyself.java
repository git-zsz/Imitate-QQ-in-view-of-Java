package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import java.awt.Font;

public class QQMyself extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QQMyself frame = new QQMyself();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QQMyself() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 520);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel touxiang = new JLabel("\u5934\u50CF");
		touxiang.setBackground(new Color(0, 0, 0));
		touxiang.setForeground(new Color(210, 105, 30));
		touxiang.setBounds(42, 27, 48, 48);
		contentPane.add(touxiang);
		
		textField = new JTextField();
		textField.setBounds(152, 13, 214, 32);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(152, 58, 529, 32);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JPanel �������� = new JPanel();
		��������.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u4E2A\u4EBA\u8D44\u6599", TitledBorder.LEFT, TitledBorder.ABOVE_TOP, null, new Color(0, 0, 0)));
		��������.setBounds(14, 103, 681, 357);
		contentPane.add(��������);
		��������.setLayout(null);
		
		JLabel label = new JLabel("\u771F\u5B9E\u540D\u5B57:");
		label.setBounds(37, 54, 73, 34);
		��������.add(label);
		
		textField_2 = new JTextField();
		textField_2.setBounds(117, 54, 156, 34);
		��������.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6027\u522B\uFF1A");
		label_1.setBounds(352, 54, 56, 34);
		��������.add(label_1);
		
		JRadioButton boy = new JRadioButton("\u7537");
		boy.setBounds(418, 58, 51, 27);
		��������.add(boy);
		
		JRadioButton gril = new JRadioButton("\u5973");
		gril.setBounds(475, 58, 51, 27);
		��������.add(gril);
		
		JLabel birthday = new JLabel("\u51FA\u751F\u5E74\u6708:");
		birthday.setBounds(37, 110, 73, 34);
		��������.add(birthday);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(117, 110, 67, 34);
		��������.add(comboBox);
		
		JLabel year = new JLabel("\u5E74");
		year.setFont(new Font("����", Font.PLAIN, 19));
		year.setHorizontalAlignment(SwingConstants.CENTER);
		year.setBounds(191, 110, 32, 34);
		��������.add(year);
		
		JComboBox mon = new JComboBox();
		mon.setBounds(267, 110, 67, 34);
		��������.add(mon);
		
		JLabel yue = new JLabel("\u6708");
		yue.setHorizontalAlignment(SwingConstants.CENTER);
		yue.setFont(new Font("����", Font.PLAIN, 19));
		yue.setBounds(333, 110, 32, 34);
		��������.add(yue);
		
		JComboBox day = new JComboBox();
		day.setBounds(394, 110, 67, 34);
		��������.add(day);
		
		JLabel label_3 = new JLabel("\u65E5");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("����", Font.PLAIN, 19));
		label_3.setBounds(472, 110, 32, 34);
		��������.add(label_3);
		
		JLabel label_2 = new JLabel("\u5907   \u6CE8\uFF1A");
		label_2.setBounds(37, 166, 73, 34);
		��������.add(label_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(115, 171, 475, 129);
		��������.add(textField_3);
		textField_3.setColumns(10);
	}
}
