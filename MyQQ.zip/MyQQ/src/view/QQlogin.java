package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;

import Login.NetService;
import mapper.Config;
import net.sf.json.JSONObject;
import util.SizeCenter;

import java.awt.Color;
import javax.swing.UIManager;

public class QQlogin extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	private JTextField password;
	private JTextField reg_username;
	private JTextField code;
	private JTextField regp0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QQlogin frame = new QQlogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}); 
	}

	/**
	 * Create the frame.
	 */
	public QQlogin() {
		setTitle("MyQQ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 430, 333);//695   333
		//��Ļ����
		setLocation(SizeCenter.getXY(this.getSize()));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel TXTusername = new JLabel("\u7528\u6237\u540D:");
		TXTusername.setFont(new Font("����", Font.PLAIN, 19));
		TXTusername.setBounds(38, 119, 83, 32);
		contentPane.add(TXTusername);
		
		JLabel TXTpassword = new JLabel("\u5BC6  \u7801:");
		TXTpassword.setFont(new Font("����", Font.PLAIN, 19));
		TXTpassword.setBounds(38, 166, 83, 32);
		contentPane.add(TXTpassword);
		
		username = new JTextField();
		username.setBounds(148, 121, 199, 32);
		contentPane.add(username);
		username.setColumns(10);
		
		password = new JTextField();
		password.setColumns(10);
		password.setBounds(148, 168, 199, 32);
		contentPane.add(password);
		
		JButton loginbutton = new JButton("\u767B\u5F55");
		loginbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username_str = username.getText().trim();
				String password_str = password.getText().trim();
				System.out.println(username_str);
				System.out.println(password_str);
				if (username_str.trim().equals("") || password_str.trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "�û��������������д!");
					return;
				}
				Config.username = username_str;
				Config.password = password_str;
				try {
					
					JSONObject json = NetService.getNetService().login();
					
					if (json.getInt("state") == 0) {
						//��¼�ɹ�����ʾ�����б�
						new HaoyouliebiaoDialog().setVisible(true);
						QQlogin.this.setVisible(false);
						/*QQlogin.this.dispose();*/
					} else {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, json.getString("msg"));
					}

				} catch (Exception e1) {
					e1.printStackTrace();
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "��������ʧ��!");
				}
			}
		
		
		});
		loginbutton.setBounds(220, 221, 113, 42);
		contentPane.add(loginbutton);
		
		JButton zuce = new JButton("\u6CE8\u518C");
		zuce.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(QQlogin.this.getHeight()==695){
					QQlogin.this.setSize( 430,333);
				}else{
					QQlogin.this.setSize( 430,695);
				}
				setLocation(SizeCenter.getXY(QQlogin.this.getSize()));
			}
		});
		zuce.setBounds(48, 221, 113, 42);
		contentPane.add(zuce);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u6CE8\u518C", TitledBorder.LEADING, TitledBorder.ABOVE_TOP, null, new Color(64, 64, 64)));
		panel.setBounds(14, 294, 384, 286);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u90AE  \u7BB1:");
		label.setFont(new Font("����", Font.PLAIN, 19));
		label.setBounds(25, 48, 81, 40);
		panel.add(label);
		
		reg_username = new JTextField();
		reg_username.setColumns(10);
		reg_username.setBounds(120, 50, 224, 40);
		panel.add(reg_username);
		
		JButton yanzheng = new JButton("\u53D1\u9001\u9A8C\u8BC1");
		yanzheng.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {

				if (reg_username.getText().trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "�û�������Ϊ��!");
					return;
				}
				try {
					Socket socket = new Socket(Config.IP, Config.REG_PORT);
					InputStream input = socket.getInputStream();
					OutputStream output = socket.getOutputStream();

					output.write(("{\"type\":\"code\",\"username\":\"" + reg_username.getText() + "\"}").getBytes());
					output.flush();

					byte[] bytes = new byte[1024];
					int len = input.read(bytes);
					String str = new String(bytes, 0, len);
					JSONObject json = JSONObject.fromObject(str);
					if (json.getInt("state") == 0) {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "���ͳɹ���");
					} else {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "����ʧ�ܣ��п�������ֻ��������emailд����!");
					}

					input.close();
					output.close();
					socket.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}
		});
		yanzheng.setBounds(257, 99, 113, 40);
		panel.add(yanzheng);
		
		code = new JTextField();
		code.setBounds(120, 99, 113, 40);
		panel.add(code);
		code.setColumns(10);
		
		JLabel code01 = new JLabel("\u9A8C\u8BC1\u7801:");
		code01.setFont(new Font("����", Font.PLAIN, 19));
		code01.setBounds(25, 101, 86, 38);
		panel.add(code01);
		
		JLabel reg_pas = new JLabel("\u5BC6  \u7801:");
		reg_pas.setFont(new Font("����", Font.PLAIN, 19));
		reg_pas.setBounds(25, 166, 81, 38);
		panel.add(reg_pas);
		
		JLabel reg_pass = new JLabel("\u786E\u8BA4\u5BC6\u7801:");
		reg_pass.setFont(new Font("����", Font.PLAIN, 19));
		reg_pass.setBounds(25, 227, 86, 38);
		panel.add(reg_pass);
		
		regp0 = new JTextField();
		regp0.setColumns(10);
		regp0.setBounds(120, 164, 224, 40);
		panel.add(regp0);
		
		JTextField regp1 = new JTextField();
		regp1.setColumns(10);
		regp1.setBounds(120, 227, 224, 40);
		panel.add(regp1);
		
		JButton ע�� = new JButton("\u6CE8\u518C");
		ע��.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				if (reg_username.getText().trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "�û�������Ϊ��!");
					return;
				}
				if (regp0.getText().trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "���벻��Ϊ��!");
					return;
				}
				if (regp1.getText().trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "ȷ�����벻��Ϊ��!");
					return;
				}
				if (code.getText().trim().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "��֤�벻��Ϊ��!");
					return;
				}
				if (!regp0.getText().trim().equals(regp1.getText())) {
					javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "�������벻���!");
					return;
				}
				try {
					Socket socket = new Socket(Config.IP, Config.REG_PORT);
					InputStream input = socket.getInputStream();
					OutputStream output = socket.getOutputStream();

					output.write(("{\"type\":\"reg\",\"username\":\"" + reg_username.getText() + "\",\"password\":\""
							+ regp0.getText() + "\",\"code\":\"" + code.getText() + "\"}").getBytes());
					output.flush();

					byte[] bytes = new byte[1024];
					int len = input.read(bytes);
					String str = new String(bytes, 0, len);
					JSONObject json = JSONObject.fromObject(str);
					if (json.getInt("state") == 0) {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "��ϲ��!ע��ɹ������Ե�¼�ˣ�");
						reg_username.setText("");
						reg_pas.setText("");
						reg_pass.setText("");
						code.setText("");
					} else if (json.getInt("state") == 1) {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "�û����Ѵ���!");
					} else if (json.getInt("state") == 2) {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "��֤�� �������»��!");
					} else if (json.getInt("state") == 3) {
						javax.swing.JOptionPane.showMessageDialog(QQlogin.this, "δ֪����!");
					}

					input.close();
					output.close();
					socket.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}
		});
		ע��.setBounds(240, 586, 113, 42);
		contentPane.add(ע��);
		
		JButton ���� = new JButton("\u653E\u5F03");
		����.setBounds(48, 586, 113, 42);
		contentPane.add(����);
	}
}
