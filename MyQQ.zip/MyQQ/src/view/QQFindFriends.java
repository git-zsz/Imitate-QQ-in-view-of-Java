package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class QQFindFriends extends JFrame {

	private JPanel contentPane;
	private JTextField nameinput;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QQFindFriends frame = new QQFindFriends();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	 Vector rows =new Vector();
	 Vector cols =new Vector();
	 private JTable table;
	public QQFindFriends() {
		setTitle("\u67E5\u627E\u597D\u53CB");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 659, 436);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel name = new JLabel("\u6635\u79F0 :");
		name.setFont(new Font("����", Font.PLAIN, 19));
		name.setBounds(24, 33, 72, 34);
		contentPane.add(name);
		
		nameinput = new JTextField();
		nameinput.setBounds(103, 34, 340, 36);
		contentPane.add(nameinput);
		nameinput.setColumns(10);
		
		JButton foundName = new JButton("\u67E5\u627E");
		foundName.setBounds(475, 35, 113, 34);
		contentPane.add(foundName);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 97, 603, 279);
		contentPane.add(scrollPane);
		cols.add("�ǳ�");
		cols.add("����");
		table = new JTable(rows,cols);
		scrollPane.setViewportView(table);
		
		
	}
}
