/*
Navicat MySQL Data Transfer

Source Server         : abc
Source Server Version : 50027
Source Host           : localhost:3306
Source Database       : qq

Target Server Type    : MYSQL
Target Server Version : 50027
File Encoding         : 65001

Date: 2018-06-03 11:48:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `hy`
-- ----------------------------
DROP TABLE IF EXISTS `hy`;
CREATE TABLE `hy` (
  `logid` varchar(100) NOT NULL default '',
  `uid` varchar(100) default NULL,
  `hyuid` varchar(100) default NULL,
  `createtime` datetime default NULL,
  PRIMARY KEY  (`logid`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hy
-- ----------------------------
INSERT INTO `hy` VALUES ('1', '123', '456', '2018-05-01 19:51:14');
INSERT INTO `hy` VALUES ('2', '456', '123', '2018-05-01 19:51:27');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `uid` varchar(100) NOT NULL,
  `phonenumber` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `password` varchar(100) default NULL,
  `netname` varchar(100) default NULL COMMENT '昵称',
  `info` varchar(200) default NULL,
  `yy` int(11) default '1998',
  `mm` int(11) default '1',
  `dd` int(11) default '1',
  `back` varchar(500) default NULL COMMENT '备注',
  `sex` varchar(100) default '男',
  `name` varchar(100) default NULL COMMENT '真实姓名',
  `state` int(10) unsigned zerofill default NULL COMMENT '状态',
  `createtime` datetime default NULL,
  `img` varchar(100) default NULL,
  PRIMARY KEY  (`uid`),
  UNIQUE KEY `phone` (`phonenumber`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('123', '123', '123@qq.com', '123', '2', '2', '22', null, '2', '2', '2', '2', '0000000000', '2018-05-16 19:19:06', '0');
INSERT INTO `users` VALUES ('456', null, '861963152@qq.com', '123', '你还', '66', '1998', '1', '1', null, '男', null, null, '2018-05-31 17:05:51', '1');
